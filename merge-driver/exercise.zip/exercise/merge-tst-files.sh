echo ""
echo "#########################"
echo "# TST merge tool called #"
echo "#########################"
echo ""
echo "Resolving conflicts..."
echo '[                    ]\r\c'
sleep 1
echo '[===                 ]\r\c'
sleep 1
echo '[===========         ]\r\c'
sleep 1
echo '[====================]\r\c'
sleep 1
echo "[H A R M O N Y]" > $2
echo '\nConflict resolved!'
sleep 1
echo ""
exit 0
